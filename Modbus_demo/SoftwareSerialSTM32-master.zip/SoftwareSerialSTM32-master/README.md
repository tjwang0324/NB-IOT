# SoftwareSerialSTM32

Multi-instance software serial library for Arduino/Wiring

o Based on Arduino SoftSerial Library with added conditional 
  compile for STM32Duino
  
o Usage documentation available at:
  https://www.arduino.cc/en/Reference/SoftwareSerial
  


The original AVR only source code can be found at
https://github.com/arduino/Arduino/tree/master/hardware/arduino/avr/libraries/SoftwareSerial

License
Licenses are documented in the files themselves.

